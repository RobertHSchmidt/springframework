	Java Naming and Directory Interface(TM) (JNDI)
	     LDAP Booster Pack 1.0 Release Notes
		       May, 2003


This is the 1.0 release of the JNDI LDAP Booster Pack.  Please send
feedback on this release to jndi@java.sun.com, or to the public
mailing list at jndi-interest@java.sun.com.


IMPORTANT NOTES

1. This software is NOT an LDAP service provider; it works in
conjunction with an LDAP service provider.  It must be installed into
a Java 2 Standard Edition (J2SE) SDK or Runtime Environment (JRE) that
already has a JNDI/LDAP service provider.

2. The APIs of the classes contained in the Booster Pack are SUBJECT
TO CHANGE, mainly because most of the controls, extensions, and schema
on which they are based are still in proposal stage at the IETF, and
have not been standardized.

3. The recommended version of the J2SE platform to use with this
release is 1.4.x.


RELEASE CONTENTS

doc/ldapbp/ldapbp-install.html
	Installation instructions for the booster pack.

doc/ldapbp/ldapbp-overview.html
	Documentation for how to use the software in the booster pack.

doc/ldapbp/api/
	javadocs for the public classes in the booster pack.

lib/ldapbp.jar
	Archive ("booster pack") for supporting various LDAP controls and
	extensions. It also contains support for groups and reading/storing
	Java(TM) Remote Method Invocation and CORBA objects in an LDAP
	directory, and a few SASL authentication mechanisms.


ADDITIONAL INFORMATION

http://java.sun.com/products/jndi/tutorial/
	The JNDI Tutorial

http://java.sun.com/j2se/1.4/docs/api/
	JNDI javadocs (included with J2SE 1.4 javadocs)

http://www.ietf.org/rfc/rfc2713.txt
	Documentation of the schema for representing objects in the 
        Java(TM) programming language in an LDAP directory.

http://www.ietf.org/rfc/rfc2714.txt
	Documentation of the schema for representing CORBA objects 
	in an LDAP directory.
